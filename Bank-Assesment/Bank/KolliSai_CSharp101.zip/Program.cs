﻿namespace Bank;

internal class Program
{
    static void Main(string[] args)
    {
        Menu.ShowMenu();
    }
}
