﻿namespace Bank;

public enum AccountType
{
    SavingsAccount,
    FixedDepositAccount
}
