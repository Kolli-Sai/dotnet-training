﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo
{
    internal abstract class Employee
    {
        public abstract void IncreaseSalary(int salary);
    }
}
