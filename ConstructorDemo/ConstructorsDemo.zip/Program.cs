﻿namespace ConstructorDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Child c1 = new Child("sai","venkanna","durga","kolli");
            Console.WriteLine(c1.SurName);
        }
    }
}
